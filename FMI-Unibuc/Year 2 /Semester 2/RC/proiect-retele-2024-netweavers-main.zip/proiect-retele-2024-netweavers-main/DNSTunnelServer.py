import base64
import os
import socket
import dns.resolver
from scapy.all import *

# Function to resolve a domain name to its corresponding IP addresses
def resolve_domain_to_ip(domain):
    try:
        # Resolve the domain name to A records (IPv4 addresses)
        answers = dns.resolver.resolve(domain, 'A')
        ip_addresses = [answer.address for answer in answers]
        return ip_addresses
    except dns.resolver.NXDOMAIN:
        # If the domain does not exist, return an empty list
        return []
    except Exception as e:
        print(f"Error resolving domain {domain}: {e}")
        return []

# Function to read a file and yield its contents in chunks of a specified size
def get_file_chunks(file_path, chunk_size=255):
    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            yield chunk

# Function to handle file requests
def handle_file_request(dns, packet, src_addr, simple_udp):
    file_name = 'cevaAcolo.txt'  # The file to be sent
    file_path = os.path.join(os.getcwd(), file_name)  # Get the absolute path of the file
    if os.path.isfile(file_path):
        try:
            chunks = list(get_file_chunks(file_path))  # Read the file in chunks
            print(f"Sending file {file_name} to client...")
            for i, chunk in enumerate(chunks):
                # Encode the chunk in base64 and prepare a DNS response
                chunk_encoded = base64.b64encode(chunk).decode()
                dns_response = IP(dst=src_addr[0]) / UDP(dport=8080, sport=8080) / DNS(
                    id=dns.id,
                    qr=1,
                    aa=1,
                    qd=dns.qd,
                    an=DNSRR(rrname=dns.qd.qname, ttl=330, type="TXT", rdata=chunk_encoded)
                )
                # Send the DNS response
                send(dns_response, verbose=0)
                print(f"Sent chunk {i + 1}/{len(chunks)}: {chunk_encoded[:50]}...")  # Print the first 50 characters of the chunk
                # Decode the chunk for verification
                decoded_chunk = base64.b64decode(chunk_encoded)
                print(f"Decoded chunk: {decoded_chunk}")
            print(f"File {file_name} sent successfully.")
        except Exception as e:
            print(f"Error reading file {file_name}: {e}")
    else:
        print(f"File not found: {file_name}")

# Function to handle standard DNS requests
def handle_standard_request(dns, src_addr, simple_udp):
    domain = dns.qd.qname.decode().strip('.')  # Extract the domain name from the DNS query
    ip_addresses = resolve_domain_to_ip(domain)  # Resolve the domain name to IP addresses
    
    if dns.qd.qtype == 1:  # Type A (IPv4 address)
        if ip_addresses:
            print(f"Resolved IP addresses for {domain}: {ip_addresses}")
            # Prepare DNS answers with the resolved IP addresses
            dns_answers = [DNSRR(rrname=dns.qd.qname, ttl=330, type="A", rclass="IN", rdata=ip) for ip in ip_addresses]
        else:
            # If no IP addresses are found, return a placeholder address
            dns_answers = [DNSRR(rrname=dns.qd.qname, ttl=330, type="A", rclass="IN", rdata='0.0.0.0')]
    elif dns.qd.qtype == 2:  # Type NS (Name Server)
        # Return a predefined name server
        dns_answers = [DNSRR(rrname=dns.qd.qname, ttl=330, type="NS", rclass="IN", rdata='nsbosts.netweavers.software')]
    else:
        return None  # If the query type is neither A nor NS, do nothing

    # Prepare the DNS response
    dns_response = DNS(
        id=dns.id,
        qr=1,
        aa=0,
        rcode=0,
        qd=dns.qd,
        an=dns_answers
    )
    
    # Send the DNS response
    simple_udp.sendto(bytes(dns_response), src_addr)
    print('Response:')
    print(dns_answers)

def main():
    print("Starting DNS server...")
    # Create a UDP socket to listen for incoming DNS requests
    simple_udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, proto=socket.IPPROTO_UDP)
    simple_udp.bind(('0.0.0.0', 8080))  # Bind the socket to all interfaces on port 8080

    while True:
        request, src_addr = simple_udp.recvfrom(65535)  # Receive a DNS request
        packet = DNS(request)  # Parse the DNS packet
        dns = packet.getlayer(DNS)
        
        if dns is not None and dns.opcode == 0:  # Standard query
            print("Got: ")
            print(packet.summary())
            domain = dns.qd.qname.decode().strip('.')  # Extract the domain name from the query
            
            if domain.endswith('.tunel.live'):
                # Handle file requests for domains ending in '.tunel.live'
                handle_file_request(dns, packet, src_addr, simple_udp)
            else:
                # Handle standard DNS requests for other domains
                handle_standard_request(dns, src_addr, simple_udp)

    simple_udp.close()  # Close the UDP socket when done

if __name__ == "__main__":
    main()  # Run the main function
