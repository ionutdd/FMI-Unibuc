import socket
from urllib.parse import urlparse

def get_ip_address(url):
    try:
        # Parse the URL to extract the hostname
        parsed_url = urlparse(url)
        hostname = parsed_url.hostname or url
        # Get the IP address of the provided hostname
        ip_address = socket.gethostbyname(hostname)
        return ip_address
    except socket.gaierror:
        return "Invalid URL or unable to get IP address"

# Example usage
if __name__ == "__main__":
    url = input("Enter the URL of the site: ")
    ip_address = get_ip_address(url)
    print(f"The IP address of {url} is {ip_address}")
    
