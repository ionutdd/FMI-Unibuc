import subprocess

def check_arp_table(ip):
    result = subprocess.run(['arp', '-a'], capture_output=True, text=True)
    for line in result.stdout.splitlines():
        if ip in line:
            print(line)

# IP addresses to check
ips_to_check = ["198.7.0.2", "172.7.0.1", "172.7.0.2"]
for ip in ips_to_check:
    print(f"Checking ARP table for {ip}:")
    check_arp_table(ip)
    print()
