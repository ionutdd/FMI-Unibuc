import socket
import traceback
import struct
import time
import requests
import plotly.express as px
import pandas as pd

# Constants
MAX_HOPS = 30  # Maximum number of hops for the traceroute
DEST_PORT = 33434  # Arbitrary port number for traceroute, typically in the range 33434-33534
TIMEOUT = 3  # Timeout in seconds for receiving ICMP responses

# Function to get IP address information from an external API
def get_ip_info(ip):
    url = f"http://ip-api.com/json/{ip}"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if data['status'] == 'success':
            return data
        else:
            return {'error': 'Invalid IP address or request failed.'}
    else:
        return {'error': 'Failed to retrieve data.'}

# Function to perform traceroute
def traceroute(ip):
    try:
        # Prepare the sockets for sending UDP packets and receiving ICMP responses
        udp_send_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, proto=socket.IPPROTO_UDP)
        icmp_recv_sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
        icmp_recv_sock.settimeout(TIMEOUT)
    except PermissionError:
        print("Permission denied: You need to run this script with administrative privileges.")
        return []
    
    # List to store each hop's address and information
    hops = []
    
    # Loop through each TTL (Time To Live) value from 1 to MAX_HOPS
    for ttl in range(1, MAX_HOPS + 1):
        try:
            # Set the TTL for the outgoing UDP packets
            udp_send_sock.setsockopt(socket.SOL_IP, socket.IP_TTL, ttl)
            
            # Send the UDP packet to the destination IP address
            udp_send_sock.sendto(b'salut', (ip, DEST_PORT))
            
            try:
                # Record the time the packet is sent
                start_time = time.time()
                
                # Receive the ICMP response
                data, addr = icmp_recv_sock.recvfrom(65535)
                elapsed_time = (time.time() - start_time) * 1000  # Convert to milliseconds
                
                # Extract the ICMP type and code from the response
                icmp_header = data[20:28]
                icmp_type, icmp_code, _, _, _ = struct.unpack('!BBHHH', icmp_header)
                
                # Get IP information
                ip_info = get_ip_info(addr[0])
                if 'error' in ip_info:
                    ip_info_str = ip_info['error']
                else:
                    ip_info_str = f"({ip_info.get('country', 'N/A')}, {ip_info.get('city', 'N/A')}, {ip_info.get('isp', 'N/A')})"
                
                # Print the current hop, the round-trip time, and IP information
                print(f"{ttl}\t{addr[0]}\t{elapsed_time:.3f} ms\t{ip_info_str}")
                
                # Store the hop's address and information
                hops.append((ttl, addr[0], elapsed_time, ip_info_str))
                
                # If we received an ICMP Destination Unreachable message (type 3, code 3), we've reached the destination
                if icmp_type == 3 and icmp_code == 3:
                    print("Reached destination.")
                    break
            except socket.timeout:
                # If the ICMP response is not received within the timeout period, print a timeout message
                print(f"{ttl}\t*\t*\t*")
            except Exception as e:
                # Handle any other exceptions that may occur
                print(f"Error: {e}")
                print(traceback.format_exc())
                break
        except socket.error as e:
            # Handle socket errors
            print(f"Socket error: {e}")
            break
    
    # Close the sockets
    udp_send_sock.close()
    icmp_recv_sock.close()
    
    return hops

if __name__ == "__main__":
    # List of IP addresses to traceroute
    ips = ['122.228.6.145', '116.163.41.140', '41.160.6.158', '104.18.32.246', '86.124.128.146', '92.123.82.47']
    
    # Open a file to write the traceroute results
    with open('raportAdreseIPAcasaIonutMare.txt', 'w') as file:
        for ip in ips:
            # Perform traceroute for each IP address
            hops = traceroute(ip)
            ip_info = get_ip_info(ip)

            # Initialize data structure for plotting
            data = {
                "lat": [],
                "lon": [],
                "order": [],
            }

            order_counter = 1

            # Add destination IP's location to data if available
            if 'lat' in ip_info:
                data["lat"].append(float(ip_info['lat']))
                data["lon"].append(float(ip_info['lon']))
                data["order"].append(order_counter)
                order_counter += 1

            # Write the traceroute results to the file
            file.write(f"\nTraceroute to {ip}:\n")
            for hop in hops:
                file.write(f"IP Address Information for hop {hop[0]}:\n")
                file.write(f"IP: {hop[1]}\n")
                file.write(f"Round-trip time: {hop[2]:.3f} ms\n")
                file.write(f"Info: {hop[3]}\n")

                ip_info = get_ip_info(hop[1])

                # Add hop's location to data if available
                if 'lat' in ip_info:
                    data["lat"].append(float(ip_info['lat']))
                    data["lon"].append(float(ip_info['lon']))
                    data["order"].append(order_counter)
                    order_counter += 1

            # Create a DataFrame from the collected data
            df = pd.DataFrame(data)

            # Plot the traceroute path using Plotly
            fig = px.scatter_geo(df,
                                 lat='lat',
                                 lon='lon',
                                 text='order',
                                 scope='world')

            # Add lines between consecutive hops
            for i in range(len(df) - 1):
                fig.add_trace(px.line_geo(lat=[df.lat[i], df.lat[i + 1]],
                                          lon=[df.lon[i], df.lon[i + 1]]).data[0])
                    
            fig.update_traces(textposition='top right',
                              textfont=dict(size=12))       
              
            # Save the plot as an HTML file
            fig.write_html(f"traceroute_{ip}.html")
            print(f"Figure saved as traceroute_{ip}.html")
