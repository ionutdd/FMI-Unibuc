from scapy.all import *
import socket

def get_ip_address(domain):
    try:
        ip_address = socket.gethostbyname(domain)
        return ip_address
    except socket.gaierror:
        return None

print("Starting DNS server...")
simple_udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, proto=socket.IPPROTO_UDP)
simple_udp.bind(('0.0.0.0', 8080))

while True:
    request, adresa_sursa = simple_udp.recvfrom(65535)
    # convert payload to Scapy packet
    packet = DNS(request)
    dns = packet.getlayer(DNS)
    
    if dns is not None and dns.opcode == 0:
        print("Got: ")
        print(packet.summary())
        
        if dns.qd.qtype == 1:  # Type A
            dns_answer = DNSRR(
                rrname=dns.qd.qname,
                ttl=330,
                type="A",
                rclass="IN",
                rdata='165.232.78.238'
            )
        elif dns.qd.qtype == 2:  # Type NS
            dns_answer = DNSRR(
                rrname=dns.qd.qname,
                ttl=330,
                type="NS",
                rclass="IN",
                rdata='nsbosts.netweavers.software' 
            )
        else:
            continue  # If the query type is neither A nor NS, continue to the next request
        
        dns_response = DNS(
            id=packet[DNS].id,
            qr=1,
            aa=0,
            rcode=0,
            qd=packet.qd,
            an=dns_answer
        )
        
        print('Response:')
        print(dns_response.summary())
        simple_udp.sendto(bytes(dns_response), adresa_sursa)

simple_udp.close()
