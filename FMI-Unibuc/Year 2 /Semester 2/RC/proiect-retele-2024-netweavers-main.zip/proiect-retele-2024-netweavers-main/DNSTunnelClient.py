import socket
import base64
from scapy.all import IP, UDP, DNS, DNSQR, send

def create_dns_query(domain):
    print(f"Creating DNS query for domain: {domain}")
    return IP(dst="165.232.78.238") / UDP(dport=8080, sport=8080) / DNS(rd=1, qd=DNSQR(qname=domain))

def main():
    file_name = "cevaAcolo.txt"  # Name of the file you want to download
    domain = f"{file_name}.tunel.live"

    dns_query = create_dns_query(domain)
    print(f"Sending DNS query for file: {file_name}")
    send(dns_query, verbose=1)  # Enable verbose to see the sending details

    # Sniff for DNS responses and print source IP
    file_content = b""
    print("Starting to listen for UDP responses...")

    # Create a UDP socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client_socket.bind(('0.0.0.0', 8080))  # Bind to all interfaces on port 8080

    # Set a timeout for the socket
    client_socket.settimeout(10)  # Timeout in seconds

    try:
        while True:
            try:
                data, addr = client_socket.recvfrom(4096)
                print(f"Received packet from {addr}")
                dns_response = DNS(data)
                if dns_response.an and dns_response.an.type == 16:  # TXT record
                    rdata = dns_response.an.rdata
                    if isinstance(rdata, list):
                        rdata = b''.join(rdata)
                    try:
                        decoded_chunk = base64.b64decode(rdata)
                        print(f"Decoded chunk: {decoded_chunk[:50]}...")  # Print first 50 bytes of decoded chunk
                        file_content += decoded_chunk
                    except Exception as e:
                        print(f"Error decoding chunk: {e}")
            except socket.timeout:
                print("Socket timeout reached, no more packets received")
                break #Exit the loop on timeout
    except Exception as e:
        print(e)  # Exit the loop when interrupted

    client_socket.close()

    if file_content:
        with open(f"received_{file_name}", "wb") as f:
            f.write(file_content)
            print(f"File {file_name} received and saved as received_{file_name}")
    else:
        print(f"No content received for file {file_name}")

if __name__ == "__main__":
    main()
